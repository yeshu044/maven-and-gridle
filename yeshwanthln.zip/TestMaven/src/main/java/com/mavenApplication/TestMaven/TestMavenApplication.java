package com.mavenApplication.TestMaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestMavenApplication.class, args);
		System.out.println("hello world");
	}

}
