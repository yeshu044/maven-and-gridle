package com.GradleProject.TestGradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestGradleApplication.class, args);
		System.out.println("hello world");
	}

}
